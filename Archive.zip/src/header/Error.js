import React from "react";

const Error=()=>{

  return(
    <>
    <p>efefqe</p>
    </>
  )
};

export default Error;
