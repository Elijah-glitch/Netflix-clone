import React from "react";

const  SimilarFetch=(props)=>{
    
  const [mf,setmf]=React.useState(false)
  console.log("new val"+props.tmdbId)
  
  
  return(
   <>
   </>
  )
}
export default SimilarFetch